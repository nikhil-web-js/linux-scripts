#!/usr/bin/env bash
# Installs the Hubstaff Tracker GNOME Shell extension for the current user.
# Usage: ./install.sh            (prompts for your PAT; press Enter to skip)
#        HUBSTAFF_PAT=xxxx ./install.sh
set -euo pipefail

UUID="hubstaff-tracker@local"
SCHEMA="org.gnome.shell.extensions.hubstaff-tracker"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/gnome-shell/extensions/$UUID"

# Supports both the folder layout and a flat directory of downloaded files.
if [ -d "$HERE/$UUID" ]; then
  SRC="$HERE/$UUID"
else
  SRC="$HERE"
fi
for f in extension.js prefs.js metadata.json; do
  [ -f "$SRC/$f" ] || { echo "Missing $f in $SRC"; exit 1; }
done
SCHEMA_XML="$(ls "$SRC"/schemas/*.gschema.xml "$SRC"/*.gschema.xml 2>/dev/null | head -n1 || true)"
[ -n "$SCHEMA_XML" ] || { echo "Missing *.gschema.xml in $SRC"; exit 1; }
command -v glib-compile-schemas >/dev/null || {
  echo "glib-compile-schemas missing. Run: sudo apt install libglib2.0-bin"; exit 1; }

echo "==> Copying extension to $DEST"
rm -rf "$DEST"
mkdir -p "$DEST/schemas"
cp "$SRC/extension.js" "$SRC/prefs.js" "$SRC/metadata.json" "$DEST"/
cp "$SCHEMA_XML" "$DEST/schemas/"

echo "==> Compiling GSettings schema"
glib-compile-schemas "$DEST/schemas"

PAT="${HUBSTAFF_PAT:-}"
if [ -z "$PAT" ] && [ -t 0 ]; then
  read -r -s -p "Hubstaff personal access token (Enter to skip, set later in prefs): " PAT
  echo
fi
if [ -n "$PAT" ]; then
  echo "==> Saving PAT"
  GSETTINGS_SCHEMA_DIR="$DEST/schemas" gsettings set "$SCHEMA" pat "$PAT"
fi

echo "==> Enabling extension"
if gnome-extensions enable "$UUID" 2>/dev/null; then
  echo "Enabled."
else
  echo "GNOME Shell hasn't discovered the extension yet."
fi

cat <<MSG

Done. Next steps:
  1. Log out and back in (required on Wayland for the shell to detect a new extension).
  2. Run: gnome-extensions enable $UUID   (skip if it said "Enabled." above)
  3. Set/change the PAT any time: gnome-extensions prefs $UUID
  4. Logs: journalctl -f -o cat /usr/bin/gnome-shell
MSG
