// Hubstaff web timer bridge.
//  - The header pill shows the CURRENT SESSION. The daily total is the
//    "Today: H:MM:SS" line in the timer popup (visible when the popup is open).
//  - Running/stopped is read from the pill's text colour (white = running),
//    not inferred from ticking, so it works in throttled background tabs.
//  - A MutationObserver reports state changes immediately.
(() => {
    const RE = /^\s*(\d{1,3}):(\d{2}):(\d{2})\s*$/;
    const TODAY_RE = /^\s*Today:?\s*(\d{1,3}):(\d{2}):(\d{2})\s*$/i;
    const MAX_TOP = 80;
    const BTN_SEL = '[data-testid="web-timer-play-stop"]';
    const PROJECT_BOX = '#select2-wt-project-select-container';

    const toSecs = m => +m[1] * 3600 + +m[2] * 60 + +m[3];
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const shown = e => Boolean(e) && e.getClientRects().length > 0;
    const log = (...a) => console.log('[hubstaff-bridge]', ...a);

    let el = null;
    let observer = null;
    let observed = null;
    let tickPending = false;
    let lastSecs = null;
    let lastChange = 0;
    let lastScan = 0;
    let lastTodayScan = 0;
    let lastSave = 0;
    let firstSeen = 0;
    let curRunning = false;
    const HEARTBEAT = 15000; // normal reporting interval; state changes report at once
    let lastSent = 0;
    let drop = null;     // pending pill drop, confirmed only if it persists
    let lastWake = 0;
    let pillAt = 0;     // when the pill text last changed (observer callbacks are not throttled)
    let lastRaw = null;
    let lastTickAt = 0;
    let stopped = false; // GNOME side is paused: no timers, no observer, no messages
    let timerId = 0;
    let lastKey = '';
    let colorTrusted = true;
    let disagree = 0;
    let st = {day: null, base: null, last: null}; // today = base + session

    // ---------- finding the pill ----------
    function inHeader(e) {
        const r = e.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.top >= 0 && r.top < MAX_TOP;
    }

    function findTimer() {
        if (el && el.isConnected && RE.test(el.textContent) && inHeader(el)) return el;
        el = null;
        const now = Date.now();
        if (now - lastScan < 5000) return null;
        lastScan = now;
        for (const e of document.body.querySelectorAll('*')) {
            if (e.childElementCount > 3) continue;
            if (!RE.test(e.textContent)) continue;
            if ([...e.children].some(c => RE.test(c.textContent))) continue;
            if (inHeader(e)) return (el = e);
        }
        return null;
    }

    // White text on the blue pill = running; blue text on white = stopped.
    function colorRunning(e) {
        const m = getComputedStyle(e).color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (!m) return null;
        return (0.299 * +m[1] + 0.587 * +m[2] + 0.114 * +m[3]) > 200;
    }

    function watch(node) {
        if (observed === node) return;
        observed = node;
        observer?.disconnect();
        observer = new MutationObserver(() => {
            if (stopped) return;
            if (el && el.isConnected) {
                const m = RE.exec(el.textContent);
                const raw = m ? toSecs(m) : null;
                if (raw !== null && raw !== lastRaw) { lastRaw = raw; pillAt = Date.now(); }
            }
            // No timer here, so a hidden tab still reports state changes at once.
            if (Date.now() - lastTickAt >= 250) tick(); else scheduleTick();
        });
        let root = node;
        for (let i = 0; i < 4 && root.parentElement; i++) root = root.parentElement;
        observer.observe(root, {
            subtree: true, characterData: true, childList: true,
            attributes: true, attributeFilter: ['class', 'style'],
        });
    }

    function halt() {
        if (stopped) return;
        stopped = true;
        if (timerId) clearInterval(timerId);
        timerId = 0;
        observer?.disconnect();
        observer = null;
        observed = null;
        log('paused from the GNOME extension, stopped. Click this page after resuming.');
    }

    function resume() {
        if (!stopped) return;
        stopped = false;
        lastKey = '';
        lastSent = 0;
        drop = null;
        timerId = setInterval(tick, HEARTBEAT);
        tick();
        // The total may have moved a lot while paused, so take an exact reading.
        setTimeout(() => syncNow().catch(() => {}), 1500);
        log('resumed');
    }

    // While stopped, the only activity is one probe after you touch the page.
    function wake() {
        const now = Date.now();
        if (!stopped || now - lastWake < 5000) return;
        lastWake = now;
        try {
            chrome.runtime.sendMessage({
                type: 'hubstaff-timer',
                payload: {event: 'note', level: 'info', message: 'wake'},
            }).then(r => { if (r && !r.paused) resume(); }, () => {});
        } catch (_e) { /* extension reloaded */ }
    }

    function scheduleTick() {
        if (stopped || tickPending) return;
        tickPending = true;
        setTimeout(() => { tickPending = false; tick(); }, 50);
    }

    // ---------- "Today" line ----------
    function findTodayNode() {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = walker.nextNode())) {
            if (!/today/i.test(n.nodeValue)) continue;
            let p = n.parentElement;
            for (let i = 0; p && i < 3; i++, p = p.parentElement) {
                const m = TODAY_RE.exec(p.textContent.trim());
                if (m && p.getClientRects().length > 0) return {secs: toSecs(m), el: p};
            }
        }
        return null;
    }

    // ---------- messaging ----------
    function send(payload) {
        try {
            chrome.runtime.sendMessage({type: 'hubstaff-timer', payload}).then(
                r => {
                    if (r?.paused) return halt();
                    if (r?.command) runCommand(r.command, r.project);
                },
                () => {});
        } catch (_e) { /* extension reloaded; refresh the page */ }
    }

    function report(level, message) {
        console.warn('[hubstaff-bridge]', message);
        send({event: 'note', level, message});
    }

    function save(force) {
        const now = Date.now();
        if (!force && now - lastSave < 10000) return;
        lastSave = now;
        try { chrome.storage.local.set({hsState: st}); } catch (_e) { /* ignore */ }
    }

    // ---------- main loop ----------
    function tick() {
        if (stopped) return;
        const t = findTimer();
        if (!t) {
            curRunning = false;
            if (lastKey !== 'nf' || Date.now() - lastSent >= HEARTBEAT) {
                lastKey = 'nf';
                lastSent = Date.now();
                send({found: false});
            }
            return;
        }
        watch(t);
        const s = toSecs(RE.exec(t.textContent));
        const now = Date.now();
        if (!firstSeen) firstSeen = now;
        if (s !== lastRaw) { lastRaw = s; pillAt = now; }
        lastTickAt = now;
        const increased = lastSecs !== null && s > lastSecs;
        if (increased) lastChange = now;
        lastSecs = s;

        const hidden = document.hidden;
        const c = colorRunning(t);
        if (c === false && increased) {
            if (++disagree >= 3) colorTrusted = false; // colour scheme differs: use ticking
        } else if (c === true) {
            disagree = 0;
        }
        const tickRunning = lastChange > 0 && now - lastChange < (hidden ? 75000 : 4000);
        curRunning = (c === null || !colorTrusted) ? tickRunning : c;

        const day = new Date().toDateString();
        if (st.day !== day) st = {day, base: null, last: null};

        let dirty = false;
        // New session (pill dropped): fold the finished one into base. Only a drop that
        // persists counts, since a refresh or half-rendered pill reads low for a moment.
        const settled = now - firstSeen >= 5000;
        let pendingDrop = false;
        if (st.base !== null && st.last !== null && s < st.last) {
            if (!drop) drop = {at: now, last: st.last};
            if (settled && now - drop.at >= 3000) {
                st.base += drop.last;
                drop = null;
                dirty = true;
            } else {
                pendingDrop = true;
            }
        } else {
            drop = null;
        }
        // Popup open: sync base from the real "Today" value. "Today" can lag the
        // pill, which only ever makes the implied base too LOW, so accept upward
        // corrections readily and downward ones only when clearly wrong.
        if (settled && !pendingDrop && now - lastTodayScan >= HEARTBEAT) {
            lastTodayScan = now;
            const tn = findTodayNode();
            if (tn) {
                const b = tn.secs - s;
                if (st.base === null || !curRunning || b - st.base >= 2 || st.base - b > 90) {
                    st.base = b;
                    dirty = true;
                }
            }
        }
        if (!pendingDrop) st.last = s;
        save(dirty);
        if (pendingDrop) return; // wait for the drop to be confirmed or to recover

        // A throttled background tab stops re-rendering the pill, so the reading can be
        // stale. While running, add the time since the pill last changed.
        const age = curRunning && pillAt ? Math.min(120, (now - pillAt) / 1000) : 0; // keep the fraction
        const se = s + age;
        const synced = consumeSynced();
        const key = String(curRunning);
        if (synced || key !== lastKey || now - lastSent >= HEARTBEAT) {
            lastKey = key;
            lastSent = now;
            send({
                found: true,
                seconds: se,
                at: now, // moment this reading is true for, in ms
                today: st.base !== null ? st.base + se : null,
                running: curRunning,
                hidden,
                synced,
            });
        }
    }

    // ---------- start / stop / project ----------
    const getBtn = () => [...document.querySelectorAll(BTN_SEL)].find(shown) ?? null;

    function buttonState(btn) {
        const play = shown(btn.querySelector('.hi-play'));
        const stop = shown(btn.querySelector('.hi-stop'));
        if (stop && !play) return 'running';
        if (play && !stop) return 'stopped';
        return 'unknown';
    }

    const fire = (e, type) => e.dispatchEvent(new MouseEvent(type, {
        bubbles: true, cancelable: true, view: window, button: 0,
    }));

    const visibleOptions = () => [...document.querySelectorAll('.select2-results__option')]
        .filter(li => shown(li) &&
            !li.classList.contains('select2-results__message') &&
            (li.hasAttribute('aria-selected') || li.getAttribute('role') === 'treeitem'));

    const projectMissing = () => {
        const box = document.querySelector(PROJECT_BOX);
        return Boolean(box) && Boolean(box.querySelector('.select2-selection__placeholder'));
    };

    function matchOption(list, textOf, wanted) {
        if (!wanted) return list[0] ?? null;
        const norm = o => textOf(o).trim().toLowerCase();
        const exact = list.find(o => norm(o) === wanted);
        if (exact) return exact;
        const partial = list.filter(o => norm(o).includes(wanted));
        return partial.length === 1 ? partial[0] : null;
    }

    async function ensureProject(name) {
        if (!projectMissing()) return;
        const wanted = (name || '').trim().toLowerCase();
        log('no project selected, choosing', wanted || '(first in list)');

        const box = document.querySelector(PROJECT_BOX).closest('.select2-selection');
        fire(box, 'mousedown');
        await sleep(500);
        let opts = visibleOptions();
        if (!opts.length) {
            fire(box, 'click');
            await sleep(500);
            opts = visibleOptions();
        }
        if (opts.length) {
            const pick = matchOption(opts, o => o.textContent, wanted);
            if (!pick) {
                throw new Error(`project "${name}" not in list: ` +
                    opts.map(o => o.textContent.trim()).join(' | '));
            }
            log('selecting option', pick.textContent.trim());
            fire(pick, 'mouseup');
            fire(pick, 'click');
            await sleep(500);
        }
        if (projectMissing()) {
            const sel = document.getElementById('wt-project-select');
            const opt = sel && matchOption([...sel.options], o => o.text, wanted);
            if (!opt) throw new Error(`project "${name}" not available`);
            log('fallback: setting select value', opt.text);
            sel.value = opt.value;
            sel.dispatchEvent(new Event('change', {bubbles: true}));
            await sleep(500);
        }
        if (projectMissing()) throw new Error('could not select a project');
    }

    let pendingSynced = false;
    const consumeSynced = () => {
        const v = pendingSynced;
        pendingSynced = false;
        return v;
    };
    let syncing = false;

    // Exact resync: read "Today" from the popup (opening it if needed) and set
    // the base so that base + session == Today, right now.
    async function syncNow() {
        if (syncing) return;
        syncing = true;
        try {
            const t = findTimer();
            if (!t) throw new Error('timer pill not found on the page');
            let tn = findTodayNode();
            let opened = false;
            if (!tn) {
                t.click();
                opened = true;
                for (let i = 0; i < 8 && !tn; i++) {
                    await sleep(300);
                    tn = findTodayNode();
                }
            }
            if (!tn) throw new Error('"Today" total not visible in the popup');
            const s = toSecs(RE.exec(t.textContent)); // read together with Today
            st = {day: new Date().toDateString(), base: tn.secs - s, last: s};
            drop = null;
            save(true);
            pendingSynced = true;
            tick();
            setTimeout(() => { lastSent = 0; tick(); }, 5000); // re-snap once the popup settles
            if (opened) {          // put the popup back the way it was
                await sleep(400);
                t.click();
            }
        } finally {
            syncing = false;
        }
    }

    let busy = false;
    const lastCmd = {};

    async function runCommand(verb, project) {
        if (verb === 'sync') {
            return syncNow().catch(e => report('error', `sync failed: ${e.message}`));
        }
        if (busy || (verb !== 'start' && verb !== 'stop')) return;
        const t0 = Date.now();
        if (t0 - (lastCmd[verb] ?? 0) < 3000) return; // duplicate delivery
        lastCmd[verb] = t0;
        busy = true;
        try {
            if (verb === 'start' && t0 - firstSeen < 6000)
                await sleep(6000 - (t0 - firstSeen)); // page just loaded: let state settle

            tick(); // commands arrive between heartbeats, so refresh state first
            let btn = getBtn();
            if (!btn) {
                if (!el) throw new Error('timer pill not found on the page');
                el.click();              // open the popup
                await sleep(800);
                btn = getBtn();
            }
            if (!btn) throw new Error('play/stop button not found');

            let state = buttonState(btn);
            if (state === 'unknown') state = curRunning ? 'running' : 'stopped';
            if (verb === 'start' && state === 'stopped' && curRunning)
                throw new Error('timer state unclear (pill says running, button says stopped)');
            if (verb === 'start' && state === 'running') return log('already running');
            if (verb === 'stop' && state === 'stopped') return log('already stopped');

            if (verb === 'start') {
                await ensureProject(project);
                btn = getBtn() ?? btn; // popup may have re-rendered
            }

            log(`${verb}: clicking`, btn);
            btn.click();
            await sleep(3000);
            if ((verb === 'start') !== curRunning)
                report('error', `${verb} clicked but the timer state did not change`);
        } catch (e) {
            report('error', `${verb} failed: ${e.message}`);
        } finally {
            busy = false;
        }
    }

    // ---------- boot ----------
    function start() {
        chrome.runtime.onMessage.addListener(msg => {
            if (msg?.type === 'hubstaff-command') runCommand(msg.command, msg.project);
        });
        tick();
        timerId = setInterval(tick, HEARTBEAT);
        // Tab brought to the front: let the pill catch up, then report at once.
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) return;
            if (stopped) return wake();
            setTimeout(() => { lastSent = 0; tick(); }, 500);
        });
        for (const ev of ['focus', 'pointerdown', 'keydown']) window.addEventListener(ev, wake, true);
    }

    try {
        chrome.storage.local.get('hsState').then(r => {
            if (r?.hsState?.day === new Date().toDateString()) st = r.hsState;
            start();
        }, start);
    } catch (_e) {
        start();
    }
})();
