// 1) Forwards timer readings to the local GNOME Shell extension and relays its
//    reply back to the page.
// 2) Checks for menu commands (start / stop / sync) once a second from here, not
//    from the page, so background-tab throttling can't delay them. The loop only
//    runs while a Hubstaff tab is open.
const BASE = 'http://127.0.0.1:47613';
const sleep = ms => new Promise(r => setTimeout(r, ms));

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type !== 'hubstaff-timer') return;
    ensureLoop(); // a page report revives the loop if the worker was restarted
    fetch(`${BASE}/timer`, {
        method: 'POST',
        headers: {'Content-Type': 'text/plain'},
        body: JSON.stringify(msg.payload),
    })
        .then(r => r.json())
        .then(j => sendResponse(j))
        .catch(() => sendResponse(null)); // GNOME extension not running
    return true; // keep the channel open for the async reply
});

async function hubstaffTabs() {
    return chrome.tabs.query({url: 'https://app.hubstaff.com/*'});
}

async function deliver(cmd) {
    const tabs = await hubstaffTabs();
    if (!tabs.length) return;
    tabs.sort((a, b) => Number(b.active) - Number(a.active));
    try {
        await chrome.tabs.sendMessage(tabs[0].id, {
            type: 'hubstaff-command', command: cmd.command, project: cmd.project,
        });
    } catch (_e) { /* tab has no content script yet */ }
}

let looping = false;
function ensureLoop() {
    if (!looping) loop();
}

async function loop() {
    looping = true;
    let fails = 0;
    try {
        for (;;) {
            chrome.runtime.getPlatformInfo(() => {}); // resets the worker idle timer
            if (!(await hubstaffTabs()).length) return; // no tab: stop, a page report restarts us
            let wait = 1000;
            try {
                const r = await fetch(`${BASE}/cmd`, {cache: 'no-store'});
                const j = await r.json();
                fails = 0;
                if (j?.command) await deliver(j);
                if (j?.paused) return; // GNOME side is paused: stay off until a page reports again
            } catch (_e) {
                fails = Math.min(fails + 1, 6);
                wait = 5000 * fails; // back off while GNOME side is off
            }
            await sleep(wait);
        }
    } finally {
        looping = false;
    }
}

ensureLoop();
