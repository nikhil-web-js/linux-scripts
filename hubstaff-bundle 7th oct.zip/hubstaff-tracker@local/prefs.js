import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class HubstaffPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const page = new Adw.PreferencesPage();
        const group = new Adw.PreferencesGroup({
            title: 'Hubstaff',
            description: 'Create a personal access token at developer.hubstaff.com/personal_access_tokens',
        });
        page.add(group);

        const paused = new Adw.SwitchRow({
            title: 'Pause monitoring',
            subtitle: 'Weekends, holidays: no polling, no notifications, no errors',
        });
        settings.bind('paused', paused, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(paused);

        const pat = new Adw.PasswordEntryRow({title: 'Personal access token'});
        settings.bind('pat', pat, 'text', Gio.SettingsBindFlags.DEFAULT);
        group.add(pat);

        const limit = new Adw.SpinRow({
            title: 'Daily limit (hours, 0 = off)',
            subtitle: 'You get a notification when today\'s total reaches this',
            adjustment: new Gtk.Adjustment({
                lower: 0, upper: 24, step_increment: 1, page_increment: 2,
            }),
        });
        settings.bind('daily-limit-hours', limit, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(limit);

        const autoStop = new Adw.SwitchRow({
            title: 'Auto-stop the timer at the limit',
            subtitle: 'Needs the Chrome extension and an open Hubstaff tab; best effort',
        });
        settings.bind('auto-stop', autoStop, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(autoStop);

        const proj = new Adw.EntryRow({title: 'Project to select on start (exact name)'});
        settings.bind('default-project', proj, 'text', Gio.SettingsBindFlags.DEFAULT);
        group.add(proj);

        const offset = new Adw.SpinRow({
            title: 'Display offset (seconds)',
            subtitle: 'Added to the displayed total; use to calibrate against the web timer',
            adjustment: new Gtk.Adjustment({
                lower: -300, upper: 300, step_increment: 1, page_increment: 10,
            }),
        });
        settings.bind('time-offset', offset, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(offset);

        const cli = new Adw.EntryRow({title: 'HubstaffCLI path (empty = auto-detect)'});
        settings.bind('cli-path', cli, 'text', Gio.SettingsBindFlags.DEFAULT);
        group.add(cli);

        const org = new Adw.EntryRow({title: 'Organization ID (optional)'});
        settings.bind('organization-id', org, 'text', Gio.SettingsBindFlags.DEFAULT);
        group.add(org);

        const poll = new Adw.SpinRow({
            title: 'Poll interval (seconds)',
            adjustment: new Gtk.Adjustment({
                lower: 5, upper: 600, step_increment: 5, page_increment: 30,
            }),
        });
        settings.bind('poll-interval', poll, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(poll);

        const thr = new Adw.SpinRow({
            title: 'Stopped after (minutes without new activity)',
            subtitle: 'Hubstaff syncs in 10-minute slots; raise this if state flickers',
            adjustment: new Gtk.Adjustment({
                lower: 1, upper: 60, step_increment: 1, page_increment: 5,
            }),
        });
        settings.bind('running-threshold', thr, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(thr);

        window.add(page);
    }
}
