import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Soup from 'gi://Soup?version=3.0';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

Gio._promisify(Soup.Session.prototype, 'send_and_read_async', 'send_and_read_finish');
Gio._promisify(Gio.Subprocess.prototype, 'communicate_utf8_async', 'communicate_utf8_finish');

const API = 'https://api.hubstaff.com/v2';
const TOKEN_URL = 'https://account.hubstaff.com/access_tokens';
const BRIDGE_PORT = 47613; // must match the Chrome extension
const SLOT_SECONDS = 600; // Hubstaff activities are 10-minute slots

function fmt(total) {
    total = Math.max(0, Math.floor(total));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const p = n => String(n).padStart(2, '0');
    return `${p(h)}:${p(m)}:${p(s)}`;
}

function parseDuration(v) {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (typeof v !== 'string') return null;
    const m = v.trim().match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?$/);
    if (!m) return null;
    return m[3] !== undefined
        ? +m[1] * 3600 + +m[2] * 60 + +m[3]
        : +m[1] * 60 + +m[2];
}

const Indicator = GObject.registerClass(
class HubstaffIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Hubstaff Tracker', false);

        const box = new St.BoxLayout({style_class: 'panel-status-menu-box'});
        this._dot = new St.Label({
            text: '○',
            y_align: Clutter.ActorAlign.CENTER,
            style: 'margin-right: 6px;',
        });
        this._time = new St.Label({
            text: '--:--:--',
            y_align: Clutter.ActorAlign.CENTER,
        });
        box.add_child(this._dot);
        box.add_child(this._time);
        this.add_child(box);

        this.statusItem = new PopupMenu.PopupMenuItem('Not synced yet', {reactive: false});
        this.syncItem = new PopupMenu.PopupMenuItem('', {reactive: false});
        this.toggleItem = new PopupMenu.PopupMenuItem('Start timer');
        this.refreshItem = new PopupMenu.PopupMenuItem('Refresh now');
        this.pauseItem = new PopupMenu.PopupMenuItem('Pause monitoring');
        this.prefsItem = new PopupMenu.PopupMenuItem('Preferences');
        this.menu.addMenuItem(this.statusItem);
        this.menu.addMenuItem(this.syncItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addMenuItem(this.toggleItem);
        this.menu.addMenuItem(this.refreshItem);
        this.menu.addMenuItem(this.pauseItem);
        this.menu.addMenuItem(this.prefsItem);
    }

    // text is "<symbol> <time>": ● running (green), ○ stopped (red),
    // ○ with no data (grey), ⚠ error (amber).
    setLabel(text, running) {
        const i = text.indexOf(' ');
        const dot = text.slice(0, i);
        const rest = text.slice(i + 1);
        let color;
        if (dot === '●') color = '#33d17a';
        else if (dot === '⏸') color = '#9a9996';
        else if (dot === '○') color = rest.includes('--') ? '#9a9996' : '#ff5a4d';
        else color = '#f8e45c';
        this._dot.set_text(dot);
        this._dot.set_style(`color: ${color}; margin-right: 6px;`);
        this._time.set_text(rest);
        this._time.set_opacity(running ? 255 : 200);
    }
});

export default class HubstaffTracker extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._session = new Soup.Session({timeout: 20});
        this._cancellable = new Gio.Cancellable();

        this._access = null;
        this._accessExpiry = 0;
        this._userId = null;
        this._orgId = null;

        this._base = 0;       // tracked seconds today at last poll
        this._polledAt = 0;   // ms timestamp of last poll
        this._running = false;
        this._hasData = false;
        this._bridge = null;  // {at, hidden} of last browser report
        this._command = null; // {verb, at}: start/stop requested from the menu

        this._indicator = new Indicator();
        this._indicator.refreshItem.connect('activate', () => this._syncNow());
        this._indicator.toggleItem.connect('activate', () => this._toggleTimer());
        this._indicator.pauseItem.connect('activate', () =>
            this._settings.set_boolean('paused', !this._paused()));
        this._indicator.menu.connect('open-state-changed', (_m, open) => {
            if (open) this._updateToggle();
        });
        this._indicator.prefsItem.connect('activate', () => this.openPreferences());
        Main.panel.addToStatusArea(this.uuid, this._indicator, 0, 'right');

        this._settingsIds = [
            this._settings.connect('changed::pat', () => {
                this._settings.set_string('refresh-token', '');
                this._access = null;
                this._userId = null;
                this._orgId = null;
                this._refresh();
            }),
            this._settings.connect('changed::organization-id', () => {
                this._orgId = null;
                this._refresh();
            }),
            this._settings.connect('changed::poll-interval', () => this._startPolling()),
            this._settings.connect('changed::paused', () => this._applyPause(true)),
        ];

        this._scheduleTick();
        this._applyPause(false);
        this._startBridge();
        this._startPolling();
        this._refresh();
    }

    disable() {
        this._cancellable?.cancel();
        if (this._tickId) GLib.source_remove(this._tickId);
        if (this._pollId) GLib.source_remove(this._pollId);
        this._tickId = this._pollId = 0;

        for (const id of this._settingsIds ?? []) this._settings.disconnect(id);
        this._settingsIds = null;

        if (this._server) {
            this._server.disconnect();
            this._server = null;
        }
        this._session?.abort();
        this._indicator?.destroy();
        this._indicator = null;
        this._session = null;
        this._cancellable = null;
        this._settings = null;
    }

    _startPolling() {
        if (this._pollId) GLib.source_remove(this._pollId);
        const secs = this._settings.get_int('poll-interval');
        this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, secs, () => {
            this._refresh();
            return GLib.SOURCE_CONTINUE;
        });
    }

    // Redraw at the moment the displayed second changes, not on a free-running 1s
    // timer. A free-running timer leaves the label up to a second behind the web pill.
    _scheduleTick() {
        if (this._tickId) GLib.source_remove(this._tickId);
        let ms = 1000;
        if (this._hasData && this._running) {
            const secs = this._base + this._settings.get_int('time-offset') +
                (Date.now() - this._polledAt) / 1000;
            ms = Math.ceil((1 - (secs - Math.floor(secs))) * 1000) + 15;
            ms = Math.min(1100, Math.max(50, ms));
        }
        this._tickId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
            this._tickId = 0;
            this._tick();
            this._scheduleTick();
            return GLib.SOURCE_REMOVE;
        });
    }

    _tick() {
        if (!this._indicator) return;
        if (!this._hasData) return;
        // Daily limit: check against the locally counted total every second, so the
        // stop goes out within about a second instead of waiting for the next report.
        if (this._running && this._bridgeFresh() && !this._command &&
            this._limitCheck({running: true}, this._base + (Date.now() - this._polledAt) / 1000))
            this._command = {verb: 'stop', at: Date.now()};
        let secs = this._base + this._settings.get_int('time-offset');
        if (this._running) secs += (Date.now() - this._polledAt) / 1000;
        this._indicator.setLabel(`${this._running ? '●' : '○'} ${fmt(secs)}`, this._running);
    }

    // ---- HTTP ---------------------------------------------------------

    async _http(method, url, {headers = {}, body = null, contentType = null} = {}) {
        const msg = Soup.Message.new(method, url);
        const h = msg.get_request_headers();
        for (const [k, v] of Object.entries(headers)) h.append(k, v);
        if (body !== null) {
            msg.set_request_body_from_bytes(
                contentType, new GLib.Bytes(new TextEncoder().encode(body)));
        }
        const bytes = await this._session.send_and_read_async(
            msg, GLib.PRIORITY_DEFAULT, this._cancellable);
        const status = msg.get_status();
        const text = new TextDecoder().decode(bytes.get_data() ?? new Uint8Array());
        if (status < 200 || status >= 300) {
            const err = new Error(`HTTP ${status} ${url.split('?')[0].replace(API, '')}: ${text.slice(0, 200)}`);
            err.status = status;
            throw err;
        }
        return text ? JSON.parse(text) : {};
    }

    async _exchange(refreshToken) {
        const body = `grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`;
        const res = await this._http('POST', TOKEN_URL, {
            body, contentType: 'application/x-www-form-urlencoded',
        });
        this._access = res.access_token;
        this._accessExpiry = Date.now() + (res.expires_in ?? 3600) * 1000;
        // Hubstaff may rotate the refresh token; keep the newest one.
        if (res.refresh_token && res.refresh_token !== refreshToken)
            this._settings.set_string('refresh-token', res.refresh_token);
    }

    async _ensureAccess() {
        if (this._access && Date.now() < this._accessExpiry - 120000) return;
        const pat = this._settings.get_string('pat').trim();
        const stored = this._settings.get_string('refresh-token').trim();
        if (!pat && !stored) throw new Error('No personal access token set (open Preferences)');
        try {
            await this._exchange(stored || pat);
        } catch (e) {
            // Stored rotated token stale? Fall back to the original PAT.
            if (stored && pat && (e.status === 400 || e.status === 401))
                await this._exchange(pat);
            else
                throw e;
        }
    }

    async _api(path, retry = true) {
        await this._ensureAccess();
        try {
            return await this._http('GET', `${API}${path}`, {
                headers: {Authorization: `Bearer ${this._access}`},
            });
        } catch (e) {
            if (e.status === 401 && retry) {
                this._access = null;
                return this._api(path, false);
            }
            throw e;
        }
    }

    // ---- Hubstaff logic -----------------------------------------------

    async _resolveIds() {
        if (!this._userId) {
            const me = await this._api('/users/me');
            this._userId = me.user.id;
        }
        if (!this._orgId) {
            const override = this._settings.get_string('organization-id').trim();
            if (override) {
                this._orgId = override;
            } else {
                let orgs;
                try {
                    orgs = await this._api('/organizations');
                } catch (e) {
                    if (e.status !== 404) throw e;
                    orgs = await this._api('/users/me/organizations');
                }
                const first = orgs.organizations?.[0];
                if (!first) throw new Error('No organizations found');
                this._orgId = first.id;
            }
        }
    }

    async _fetchToday() {
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        const stop = new Date();

        let total = 0;
        let lastEnd = 0; // seconds since epoch
        let pageStart = null;
        do {
            let q = `/organizations/${this._orgId}/activities` +
                `?time_slot%5Bstart%5D=${encodeURIComponent(start.toISOString())}` +
                `&time_slot%5Bstop%5D=${encodeURIComponent(stop.toISOString())}` +
                `&user_ids=${this._userId}&page_limit=500`;
            if (pageStart) q += `&page_start_id=${pageStart}`;
            const res = await this._api(q);
            for (const a of res.activities ?? []) {
                total += a.tracked ?? 0;
                const slotStart = Date.parse(a.starts_at) / 1000;
                if (!Number.isNaN(slotStart))
                    lastEnd = Math.max(lastEnd, slotStart + SLOT_SECONDS);
            }
            pageStart = res.pagination?.next_page_start_id ?? null;
        } while (pageStart);

        return {total, lastEnd};
    }

    // ---- Source 0: Hubstaff web timer, pushed by the Chrome extension ----

    _startBridge() {
        try {
            this._server = new Soup.Server();
            this._server.add_handler('/timer', (_server, msg) => this._onBridge(msg));
            this._server.add_handler('/cmd', (_server, msg) => this._onCmd(msg));
            this._server.listen_local(BRIDGE_PORT, Soup.ServerListenOptions.IPV4_ONLY);
        } catch (e) {
            console.error(`[hubstaff-tracker] bridge listen failed on ${BRIDGE_PORT}: ${e.message}`);
            this._server = null;
        }
    }

    _onBridge(msg) {
        const h = msg.get_response_headers();
        h.append('Access-Control-Allow-Origin', '*');
        h.append('Access-Control-Allow-Headers', 'Content-Type');
        h.append('Access-Control-Allow-Private-Network', 'true');
        try {
            let command = null;
            if (msg.get_method() === 'POST' && !this._paused()) {
                const raw = msg.get_request_body().flatten().get_data();
                const p = JSON.parse(new TextDecoder().decode(raw));
                if (p.event === 'note') {
                    if (p.level === 'error')
                        Main.notify('Hubstaff', String(p.message).slice(0, 200));
                    p.found = false;
                } else {
                    this._applyBridge(p);
                }
                if (p.found) {
                    command = this._takeCommand(p);
                    if (!command && p.today !== null && p.today !== undefined &&
                        this._limitCheck(p, Number(p.today)))
                        command = 'stop';
                }
            }
            msg.set_status(200, null);
            msg.set_response('application/json', Soup.MemoryUse.COPY,
                new TextEncoder().encode(JSON.stringify({
                    command,
                    paused: this._paused(),
                    project: command === 'start'
                        ? this._settings.get_string('default-project').trim() : '',
                })));
        } catch (e) {
            console.error(`[hubstaff-tracker] bad bridge request: ${e.message}`);
            msg.set_status(400, null);
        }
    }

    // Cheap command check, polled every second by the Chrome service worker.
    // A command is only handed out while a Hubstaff tab is reporting, otherwise
    // it stays queued for the reply to the next timer report.
    _onCmd(msg) {
        const origin = msg.get_request_headers().get_one('Origin');
        if (origin && !origin.startsWith('chrome-extension://')) {
            msg.set_status(403, null);
            return;
        }
        msg.get_response_headers().append('Cache-Control', 'no-store');
        const out = {command: null, project: ''};
        if (this._paused()) {
            out.paused = true; // tells the Chrome side to go fully quiet
        } else if (this._bridgeFresh()) {
            const cmd = this._takeCommand(null);
            if (cmd) {
                out.command = cmd;
                out.project = cmd === 'start'
                    ? this._settings.get_string('default-project').trim() : '';
                console.log(`[hubstaff-tracker] sent ${cmd} to browser`);
            }
        }
        msg.set_status(200, null);
        msg.set_response('application/json', Soup.MemoryUse.COPY,
            new TextEncoder().encode(JSON.stringify(out)));
    }

    _paused() {
        return this._settings.get_boolean('paused');
    }

    _applyPause(fromSignal) {
        const ind = this._indicator;
        if (!ind) return;
        const paused = this._paused();
        ind.toggleItem.visible = !paused;
        ind.refreshItem.visible = !paused;
        ind.pauseItem.label.set_text(paused ? 'Resume monitoring' : 'Pause monitoring');
        if (paused) {
            this._running = false;
            this._hasData = false;
            this._bridge = null;
            this._command = null;
            ind.setLabel('⏸ Paused', false);
            ind.statusItem.label.set_text('Paused: no polling, notifications or errors');
            ind.syncItem.label.set_text('');
        } else {
            this._setDoneDay(''); // resumed (by hand or automatically): no longer an auto-pause
            ind.setLabel('○ --:--:--', false);
            ind.statusItem.label.set_text('Resuming…');
            if (fromSignal) this._refresh();
        }
    }

    // Hand a pending menu command to the Chrome extension (once), if still valid.
    _takeCommand(_p) {
        const c = this._command;
        if (!c) return null;
        this._command = null; // deliver at most once
        return Date.now() - c.at <= 90000 ? c.verb : null;
    }

    // "Refresh now": with a live browser bridge, ask the page for an exact resync
    // against the "Today" total; otherwise fall back to a normal refresh.
    _syncNow() {
        if (this._bridgeFresh())
            this._command = {verb: 'sync', at: Date.now()};
        else
            this._refresh();
    }

    _toggleTimer() {
        const verb = this._running ? 'stop' : 'start';
        this._command = {verb, at: Date.now()};
        if (verb === 'start' && !this._bridgeFresh()) {
            // No Hubstaff tab reporting: open one; the command waits for it.
            try {
                Gio.AppInfo.launch_default_for_uri(
                    'https://app.hubstaff.com/', global.create_app_launch_context(0, -1));
            } catch (e) {
                console.error(`[hubstaff-tracker] cannot open browser: ${e.message}`);
            }
        }
    }

    _updateToggle() {
        const item = this._indicator?.toggleItem;
        if (!item) return;
        if (!this._bridgeFresh())
            item.label.set_text('Start timer (opens Hubstaff)');
        else
            item.label.set_text(this._running ? 'Stop timer' : 'Start timer');
    }

    // Returns true when the Chrome extension should be told to stop the timer.
    _limitCheck(p, total) {
        const hours = this._settings.get_int('daily-limit-hours');
        const day = new Date().toDateString();
        if (this._limitDay !== day) {
            this._limitDay = day;
            this._notified = false;
            this._failNotified = false;
            this._stopAttempts = 0;
            this._lastStopAt = 0;
            this._dayDone = false;
        }
        if (!p.running) {
            this._stopAttempts = 0; // stopped OK (or by hand); a restart is a fresh attempt
            // Limit was hit while tracking, the timer is now stopped, and the full
            // limit is on record: the day is done, so pause everything once.
            if (hours > 0 && this._notified && !this._dayDone && total >= hours * 3600) {
                this._dayDone = true;
                this._setDoneDay(this._today());
                Main.notify('Hubstaff', `Tracking complete. ${fmt(total)} recorded (limit ${hours}h). Extension paused.`);
                this._settings.set_boolean('paused', true);
                this._indicator?.setLabel(`✓ ${fmt(total)}`, false); // overrides the generic paused label
                this._indicator?.statusItem.label.set_text('Tracking complete for today. Resume to continue.');
            }
            return false;
        }
        if (hours <= 0 || total < hours * 3600) return false;

        if (!this._notified) {
            this._notified = true;
            Main.notify('Hubstaff', `Daily limit of ${hours}h reached (${fmt(total)} tracked).`);
        }
        if (!this._settings.get_boolean('auto-stop')) return false;

        const now = Date.now();
        if (this._stopAttempts >= 3) {
            if (!this._failNotified) {
                this._failNotified = true;
                Main.notify('Hubstaff', 'Auto-stop failed. Please stop the timer manually.');
            }
            return false;
        }
        if (now - (this._lastStopAt ?? 0) < 60000) return false;
        this._stopAttempts = (this._stopAttempts ?? 0) + 1;
        this._lastStopAt = now;
        return true;
    }

    _applyBridge(p) {
        if (!this._indicator) return;
        if (!p.found) {
            this._bridge = null; // timer not on page: fall back to other sources
            this._running = false; // and stop counting locally
            this._tick();
            return;
        }
        const hasTotal = p.today !== null && p.today !== undefined;
        const secs = Number(hasTotal ? p.today : p.seconds);
        if (!Number.isFinite(secs)) return;
        this._bridge = {at: Date.now(), hidden: Boolean(p.hidden)};
        this._base = secs;
        // The reading is true for the moment the page took it, not for when it arrived.
        const at = Number(p.at);
        this._polledAt = Number.isFinite(at) && Math.abs(Date.now() - at) < 5000
            ? at : Date.now();
        this._running = Boolean(p.running);
        this._hasData = true;
        this._indicator.statusItem.label.set_text(
            `${this._running ? 'Tracking' : 'Not tracking'} · browser` +
            (hasTotal ? '' : ' · session only'));
        this._indicator.syncItem.label.set_text(hasTotal
            ? (p.synced ? `Synced exactly ${new Date().toLocaleTimeString()}`
                : `Updated ${new Date().toLocaleTimeString()}`)
            : 'Open the timer popup once to sync today\'s total');
        this._tick();
        this._scheduleTick(); // new base, new phase
    }

    _bridgeFresh() {
        if (!this._bridge) return false;
        // Hidden tabs are throttled by Chrome, so allow a longer gap.
        return Date.now() - this._bridge.at < (this._bridge.hidden ? 180000 : 40000);
    }

    // ---- Source 1: local Hubstaff desktop app (live, exact) -------------

    _findCli() {
        const custom = this._settings.get_string('cli-path').trim();
        if (custom) return GLib.file_test(custom, GLib.FileTest.EXISTS) ? custom : null;
        const dirs = [`${GLib.get_home_dir()}/Hubstaff`, '/opt/Hubstaff', '/usr/local/Hubstaff'];
        const names = ['HubstaffCLI.bin.x86_64', 'HubstaffCLI'];
        for (const d of dirs)
            for (const n of names)
                if (GLib.file_test(`${d}/${n}`, GLib.FileTest.IS_EXECUTABLE))
                    return `${d}/${n}`;
        return GLib.find_program_in_path('HubstaffCLI');
    }

    async _readCli() {
        const path = this._findCli();
        if (!path) return null;

        let proc;
        let timeoutId = 0;
        try {
            proc = new Gio.Subprocess({
                argv: [path, 'status'],
                flags: Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE,
            });
            proc.init(this._cancellable);
            timeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 8, () => {
                timeoutId = 0;
                proc.force_exit();
                return GLib.SOURCE_REMOVE;
            });
            const [out] = await proc.communicate_utf8_async(null, this._cancellable);
            if (!proc.get_successful() || !out) return null;

            let obj;
            try {
                obj = JSON.parse(out);
            } catch (_e) {
                console.error(`[hubstaff-tracker] CLI status not JSON: ${out.trim().slice(0, 300)}`);
                return null;
            }

            const ap = obj.active_project;
            const total = [obj.tracked_today, obj.trackedToday, obj.today, obj.tracked,
                ap && typeof ap === 'object' ? ap.tracked_today : null]
                .map(parseDuration).find(v => v !== null);
            if (total === undefined) {
                console.error(`[hubstaff-tracker] CLI status has no tracked time: ${out.trim().slice(0, 300)}`);
                return null;
            }

            let running;
            if (typeof obj.tracking === 'boolean') running = obj.tracking;
            else if (typeof obj.running === 'boolean') running = obj.running;
            else running = Boolean(ap && (typeof ap !== 'object' || Object.keys(ap).length));

            return {total, running};
        } catch (e) {
            if (e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED)) throw e;
            console.error(`[hubstaff-tracker] CLI failed: ${e.message}`);
            return null;
        } finally {
            if (timeoutId) GLib.source_remove(timeoutId);
        }
    }

    // ---- Source 2: Hubstaff API (fallback, lags by many minutes) ---------

    async _readApi() {
        await this._resolveIds();
        const {total, lastEnd} = await this._fetchToday();
        const thresholdSecs = this._settings.get_int('running-threshold') * 60;
        const running = lastEnd > 0 && (Date.now() / 1000 - lastEnd) < thresholdSecs;
        return {total, running};
    }

    _setOffline() {
        this._hasData = false;
        this._running = false;
        this._indicator.setLabel('○ --:--:--', false);
        this._indicator.statusItem.label.set_text('Open app.hubstaff.com in Chrome');
        this._indicator.syncItem.label.set_text('');
    }

    _today() {
        return new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD, local time
    }

    _doneDay() {
        return this._settings.settings_schema.has_key('done-day')
            ? this._settings.get_string('done-day') : '';
    }

    _setDoneDay(v) {
        if (this._settings.settings_schema.has_key('done-day'))
            this._settings.set_string('done-day', v);
    }

    // After an automatic end-of-day pause, resume on the next calendar day. A manual
    // pause never sets done-day, so it is left alone.
    _newDayCheck() {
        const d = this._doneDay();
        if (!d || d >= this._today() || !this._paused()) return;
        this._setDoneDay('');
        this._settings.set_boolean('paused', false);
        Main.notify('Hubstaff', 'New day. Tracking resumed, counter reset.');
    }

    async _refresh() {
        this._newDayCheck();
        if (this._paused()) return;
        if (this._bridgeFresh()) return; // live browser data wins
        if (this._busy || !this._indicator) return;
        this._busy = true;
        try {
            let state = await this._readCli();
            let source = 'desktop app';
            const hasToken = this._settings.get_string('pat').trim() ||
                this._settings.get_string('refresh-token').trim();
            if (!state && !hasToken) {
                this._setOffline();
                return;
            }
            if (!state) {
                state = await this._readApi();
                source = 'API (delayed)';
            }

            this._base = state.total;
            this._polledAt = Date.now();
            this._running = state.running;
            this._hasData = true;

            this._indicator.statusItem.label.set_text(
                `${this._running ? 'Tracking' : 'Not tracking'} · ${source}`);
            this._indicator.syncItem.label.set_text(
                `Synced ${new Date().toLocaleTimeString()}`);
            this._tick();
        } catch (e) {
            if (e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED)) return;
            console.error(`[hubstaff-tracker] ${e.message}`);
            if (this._indicator) {
                this._indicator.statusItem.label.set_text(`Error: ${e.message}`.slice(0, 80));
                if (!this._hasData) this._indicator.setLabel('⚠ Hubstaff', false);
            }
        } finally {
            this._busy = false;
        }
    }
}
